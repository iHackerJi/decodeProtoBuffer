#pragma once
//struct MemoryQNode
//{
//	LIST_ENTRY listEntry;
//	PVOID memoryAddress;
//};
//
//struct ProtoQNode
//{
//	LIST_ENTRY listEntry;
//	struct ProtoNode* node;
//};

//BOOL PushMemNode(LIST_ENTRY* pListEntry, PVOID pAllocMem);
//PVOID PopMemNode(LIST_ENTRY* pListEntry);
//BOOL PushProtoNode(LIST_ENTRY* pListEntry, struct ProtoQNode* pNod);
//struct ProtoQNode* PopNode(LIST_ENTRY* pListEntry);