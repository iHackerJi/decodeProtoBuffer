#include "public.h"

struct ProtoTree* g_NodeTree = NULL;

struct ProtoTree* GetProtoTreeNode()
{
	BOOL bResult = TRUE;
	if (g_NodeTree != NULL)	return g_NodeTree;

	do 
	{
		g_NodeTree = (struct ProtoTree*)RmHeapAlloc(sizeof(struct ProtoTree));
		if (g_NodeTree == NULL)	break;

		g_NodeTree->protoRootPtr = (struct ProtoNode*)RmHeapAlloc(sizeof(struct ProtoNode));
		if (g_NodeTree->protoRootPtr == NULL) break;

		g_NodeTree->memoryFreeListHead.push_back((void*)g_NodeTree->protoRootPtr);

		bResult = TRUE;
	} while (FALSE);

	if (FALSE == bResult)
	{
		if (g_NodeTree->protoRootPtr != NULL)  RmHeapFree(g_NodeTree->protoRootPtr);
		if (g_NodeTree != NULL) RmHeapFree(g_NodeTree);
		return NULL;
	}
	else
	{
		return g_NodeTree;
	}
}

