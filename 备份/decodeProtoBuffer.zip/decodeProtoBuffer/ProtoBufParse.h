#pragma once

struct ProtoNode
{
	char* Buffer;
	uint64_t Size;
	//enum protoType nodetype;
	//union
	//{
	//	ANSI_STRING unistrBuffer;
	//	uint64_t u64Buffer;
	//	void* structBuffer;
	//}u;
	//std::vector<struct ProtoQNode> subNode;
	//unsigned long nodeNum;
};

struct ProtoTree
{
	struct ProtoNode * protoRootPtr;
	std::vector<void*> memoryFreeListHead;
	std::vector<struct ProtoNode> ergodicListHead;
};

struct ProtoTree* GetProtoTreeNode();