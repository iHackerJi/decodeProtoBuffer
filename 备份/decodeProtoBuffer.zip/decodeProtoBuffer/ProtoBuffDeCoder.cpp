#include "public.h"

int varint_read_u(const void* data, size_t len, uint64_t* x) {
	const char* str = (const char*)data;
	uint64_t b;
	*x = 0;
	if (len == 0) return 0; b = str[0]; *x |= (b & 0x7f) << (7 * 0); if (b < 0x80) return 0 + 1;
	if (len == 1) return 0; b = str[1]; *x |= (b & 0x7f) << (7 * 1); if (b < 0x80) return 1 + 1;
	if (len == 2) return 0; b = str[2]; *x |= (b & 0x7f) << (7 * 2); if (b < 0x80) return 2 + 1;
	if (len == 3) return 0; b = str[3]; *x |= (b & 0x7f) << (7 * 3); if (b < 0x80) return 3 + 1;
	if (len == 4) return 0; b = str[4]; *x |= (b & 0x7f) << (7 * 4); if (b < 0x80) return 4 + 1;
	if (len == 5) return 0; b = str[5]; *x |= (b & 0x7f) << (7 * 5); if (b < 0x80) return 5 + 1;
	if (len == 6) return 0; b = str[6]; *x |= (b & 0x7f) << (7 * 6); if (b < 0x80) return 6 + 1;
	if (len == 7) return 0; b = str[7]; *x |= (b & 0x7f) << (7 * 7); if (b < 0x80) return 7 + 1;
	if (len == 8) return 0; b = str[8]; *x |= (b & 0x7f) << (7 * 8); if (b < 0x80) return 8 + 1;
	if (len == 9) return 0; b = str[9]; *x |= (b & 0x7f) << (7 * 9); if (b < 0x80) return 9 + 1;
	return -1;
}

int varint_read_i(const void* data, size_t len, int64_t* x) {
	uint64_t ux;
	int n = varint_read_u(data, len, &ux);
	*x = (int64_t)(ux >> 1);
	if ((ux & 1) != 0) {
		*x = ~*x;
	}
	return n;
}

//#define proto_string 0
//#define proto_struct 1
//
//#define level0_1 proto_string
//#define level0_2 proto_struct
//#define level0_3 proto_string
//
//
//
//void inittestnode()
//{
//
//}

void initProtoBuff(const char* pBuffer, const uint64_t pSize)
{
	struct ProtoTree* ProtoTreeNode = GetProtoTreeNode();
	struct ProtoNode protoNode;

	memset(&protoNode, 0, sizeof(protoNode));
	protoNode.Buffer = (char*)pBuffer;
	protoNode.Size = pSize;
	ProtoTreeNode->ergodicListHead.push_back(protoNode);
}

void decodeProtoBuff(const char * pBuffer,const uint64_t pSize)
{



	unsigned long ulBufferEntryStepSize = 0;

	struct ProtoTree*  ProtoTreeNode = GetProtoTreeNode();

	for (auto &it : ProtoTreeNode->ergodicListHead)
	{
		char* bufferEntryPtr = (char*)pBuffer;
		uint64_t bufferEntrySize = pSize;
		const char* bufferMaxPtr = pBuffer + pSize;

		while (bufferEntryPtr < bufferMaxPtr || bufferEntrySize < 0)
		{
			uint64_t ul64IndexType = 0;
			int varintReadSize = 0;

			varintReadSize = varint_read_u(bufferEntryPtr, bufferEntrySize, &ul64IndexType);
			bufferEntryPtr += varintReadSize;
			bufferEntrySize -= varintReadSize;

			enum protoType type = (enum protoType)(ul64IndexType & 7);
			uint64_t ul64fieldNumber = ul64IndexType >> 3;

			switch (type)
			{
			case m_VARINT:
			{
				uint64_t ul64Value = 0;
				NTSTATUS ntStatus = STATUS_UNSUCCESSFUL;
				varintReadSize = varint_read_u(bufferEntryPtr, bufferEntrySize, &ul64Value);
				bufferEntryPtr += varintReadSize;
				bufferEntrySize -= varintReadSize;
			}
			break;
			case m_STRING:
			{
				uint64_t ul64Length = 0;
				char* bufferStringPtr = NULL;

				varintReadSize = varint_read_u(bufferEntryPtr, bufferEntrySize, &ul64Length);
				bufferEntryPtr += varintReadSize;
				bufferEntrySize -= varintReadSize;
				bufferStringPtr = (char*)RmHeapAlloc(ul64Length + 1);
				if (bufferStringPtr)
				{
					memcpy(bufferStringPtr, bufferEntryPtr, ul64Length);
					ProtoTreeNode->memoryFreeListHead.push_back(bufferStringPtr);
				}
				if (ul64Length > 0x10)
				{
					struct ProtoNode protoNode;
					memset(&protoNode, 0, sizeof(protoNode));
					protoNode.Buffer = bufferStringPtr;
				}
				else
				{
					//RtlInitAnsiString(&protoNode.u.unistrBuffer, bufferStringPtr);
				}

				bufferEntryPtr = bufferEntryPtr + ul64Length;
				bufferEntrySize = bufferEntrySize - ul64Length;
			}
			break;
			case m_FIXED32:
			{
				uint32_t u32Value = 0;
				u32Value = *(uint32_t*)bufferEntryPtr;
				bufferEntryPtr = bufferEntryPtr + 4;
				bufferEntrySize = bufferEntrySize - 4;
			}
			break;
			case m_FIXED64:
			{
				uint64_t u64Value = 0;
				u64Value = *(uint64_t*)bufferEntryPtr;
				bufferEntryPtr = bufferEntryPtr + 8;
				bufferEntrySize = bufferEntrySize - 8;
			}
			break;
			default:
				break;
			}

		}
	}



}