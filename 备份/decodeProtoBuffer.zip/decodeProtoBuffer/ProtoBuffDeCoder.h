#pragma once

void decodeProtoBuff(const char* pBuffer, const uint64_t pSize);