#pragma once


enum  protoType
{
	m_VARINT = 0,
	m_FIXED64 = 1,
	m_STRING = 2,
	m_FIXED32 = 5, 
	m_STRUCT = 999
};

